/**
 * @author Liyabona Saki
 * @St_Number 217120830
 * @Group 2I
 * @Version 1.0
 */

package runhackarthonevent;


import java.io.*;
import javax.swing.JOptionPane;



public class HackerthonUI extends javax.swing.JFrame {

    public HackerthonUI(){
        initComponents();
        this.setTitle("Hackathon Event Registration App version 1.0"); //this sets the tittle
        this.setSize(1298, 721);  //Add this code here i did find a solution for it
    }
    

    @SuppressWarnings("unchecked")
                           
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        StNo_Validate = new javax.swing.JLabel();
        St_Number = new javax.swing.JTextField();
        
        FirstName = new javax.swing.JTextField();
        LastName = new javax.swing.JTextField();
        Programme = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Yes = new javax.swing.JRadioButton();
        No1 = new javax.swing.JRadioButton();
        Yes1 = new javax.swing.JRadioButton();
        No = new javax.swing.JRadioButton();
        Exit = new javax.swing.JButton();
        Clear = new javax.swing.JButton();
        Save = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 51, 153));

        jPanel1.setBackground(new java.awt.Color(0, 0, 204));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        


//        jPanel1.setBounds(640, 400, 640, 400);
       
        


        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); 
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("Icon/hackathon.jpg"))); 
       
        jLabel1.setText("Hackathon Event Registration");

        jPanel1.add(jLabel1);



        jPanel2.setBackground(new java.awt.Color(51, 102, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(51, 102, 255));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        jLabel2.setText("First Name");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        jLabel3.setText("Student Number");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        jLabel4.setText("                                 Do you have a device (pc or laptop) :");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        jLabel5.setText("Last Name");

        St_Number.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        St_Number.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                St_NumberActionPerformed(evt);
            }
        });

        //Defining the combobox 
        Programme.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Application Development", "Communication Networks", "MultiMedia Technology" }));
        Programme.setEditor(null);
        Programme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProgrammeActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        jLabel6.setText("Programme");

        
        
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        jLabel7.setText("         Do you have access to a Data or Wifi connection :");

        //Defining the radio buttons
        Yes.setBackground(new java.awt.Color(51, 102, 255));
        Yes.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        Yes.setText("Yes");
        Yes.setEnabled(true);
        Yes.setSelected(rootPaneCheckingEnabled);
        Yes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                YesMouseClicked(evt);
            }
        });

        
        No1.setBackground(new java.awt.Color(51, 102, 255));
        No1.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        No1.setText("No");

        Yes1.setBackground(new java.awt.Color(51, 102, 255));
        Yes1.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        Yes1.setText("Yes");
        Yes1.setEnabled(true);
        Yes1.setSelected(rootPaneCheckingEnabled);

        No.setBackground(new java.awt.Color(51, 102, 255));
        No.setFont(new java.awt.Font("Tahoma", 1, 15)); 
        No.setText("No");
        
        No.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NoActionPerformed(evt);
            }
        });

        
        //Defining the Exit button
        Exit.setFont(new java.awt.Font("Tahoma", 1, 20)); 
        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

//        Defining the clear button
        Clear.setFont(new java.awt.Font("Tahoma", 1, 20)); 
        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

//       Defining the save button
        Save.setFont(new java.awt.Font("Tahoma", 1, 20)); 
        Save.setText("Save");
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(FirstName)
                                    .addComponent(St_Number)
                                    .addComponent(LastName)
                                    .addComponent(Programme, 0, 345, Short.MAX_VALUE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Yes)
                                    .addComponent(Yes1))
                                .addGap(91, 91, 91)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(No1, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(No, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(861, 861, 861))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(Clear, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(399, 399, 399))))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(52, 52, 52)
                    .addComponent(jLabel7)
                    .addContainerGap(1224, Short.MAX_VALUE)))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addComponent(Save, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 1288, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(St_Number, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(FirstName, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LastName, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Programme, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Yes)
                    .addComponent(No))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Yes1)
                    .addComponent(No1))
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Exit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Clear, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                    .addContainerGap(343, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(132, 132, 132)))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                    .addGap(0, 447, Short.MAX_VALUE)
                    .addComponent(Save, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }                       

    private void ProgrammeActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
    }                                         

    //this method clears the fields when called
    private void empty(){ 
        St_Number.setText(null);
        FirstName.setText(null);
        LastName.setText(null);
        Programme.setSelectedItem("Application Development");
        
        No.setSelected(false);
        Yes.setSelected(rootPaneCheckingEnabled);
        
        No1.setSelected(false);
        Yes1.setSelected(rootPaneCheckingEnabled);
        
       
    }
    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {                                     

//Save button

    String StudentNo = St_Number.getText();
    String firstname = FirstName.getText();
    String lastname = LastName.getText();
 
    String prog = (String) Programme.getSelectedItem();
 
    String radioBtn1 = Yes.getText();
    String radioBtn2 = No.getText();
 
 
 
    try{
        
        if (StudentNo.trim().isEmpty()){
            System.out.println("Student Number is required");
                StNo_Validate.setText("Student Number Required");
            
            if(firstname.trim().isEmpty()){
                 System.out.println("Firsname is required");   
                    }
            
            if (lastname.trim().isEmpty()){
                System.out.println("Lastname is required");
            }
            
        }else{
            
            FileWriter fw = new FileWriter("event.txt" ,true);
        
            fw.write("\nStudent Number : " + StudentNo + "\n");
            fw.write("First Name : " + firstname + "\n");
            fw.write("Last Name : " + lastname + "\n");
            fw.write("Programme : " + prog + "\n");
        
            fw.write("Do you have access to a data or wifi connection : " + radioBtn1 + "\n");
            fw.write("Do you have access to a device (pc or laptop) : " + radioBtn2 + "\n");
      
            fw.close();
        
            JOptionPane.showMessageDialog(null, "You have succesfully registered :) ");
            
          empty(); //calling the clear fields method
        
        }
        
    }catch(Exception e){
        
        JOptionPane.showMessageDialog(null, "Sorry something went wrong !");
        e.getStackTrace();
    }
        
    }                                    

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {                                      
        
      empty(); // calling the field clear method
    }                                     

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {                                     
       System.exit(0);
        
    }                                    

    private void St_NumberActionPerformed(java.awt.event.ActionEvent evt) {                                          
      
    }                                         

    private void NoActionPerformed(java.awt.event.ActionEvent evt) {                                   
      
    }                                  

    private void YesMouseClicked(java.awt.event.MouseEvent evt) {                                 
     
    }                                

                     
    private javax.swing.JButton Clear;
    private javax.swing.JButton Exit;
    private javax.swing.JTextField FirstName;
    private javax.swing.JTextField LastName;
    private javax.swing.JRadioButton No;
    private javax.swing.JRadioButton No1;
    private javax.swing.JComboBox<String> Programme;
    private javax.swing.JButton Save;
    private javax.swing.JTextField St_Number;
    private javax.swing.JRadioButton Yes;
    private javax.swing.JRadioButton Yes1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel StNo_Validate;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration                   
    
}
