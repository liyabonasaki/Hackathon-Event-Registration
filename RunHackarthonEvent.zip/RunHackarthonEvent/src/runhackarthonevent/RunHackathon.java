/**
 * @author Liyabona Saki
 * @St_Number 217120830
 * @Group 2I
 * @Version 1.0
 */

package runhackarthonevent;

public class RunHackathon {

    public static void main(String[] args) {
        // TODO code application logic here
        
         HackerthonUI ht = new HackerthonUI();
         ht.setVisible(true);
         
    }
    
}
